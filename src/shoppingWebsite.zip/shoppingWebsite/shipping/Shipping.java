package shoppingWebsite.shipping;

public class Shipping {
    public static void trackOrder() {
        System.out.println("Your Order in progress.");
    }
}
